/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lecturas;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author sergi
 */
public class ClaseBufferedReader {
    public static void main(String[] args) {
        System.out.println("Clase BufferedReader");
        try {
            FileReader archivo = new FileReader("carpeta1\\ejemplo.txt");
            BufferedReader lectura = new BufferedReader(archivo);
            
            String linea = "";
            linea = lectura.readLine();
            
            while(linea!=null){
                System.out.println(linea);
                linea = lectura.readLine();
            }
            
            lectura.close();
            
            //Leyendo todas las lineas
            archivo = new FileReader("carpeta1\\ejemplo.txt");
            lectura = new BufferedReader(archivo);
            
            List<String> misLineas = lectura.readAllLines();
            for(String linea2:misLineas){
                System.out.println(linea2);
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el archivo");
        } catch (IOException ex) {
            System.out.println("Ocurrió un error al leer");
        }
    }
}
