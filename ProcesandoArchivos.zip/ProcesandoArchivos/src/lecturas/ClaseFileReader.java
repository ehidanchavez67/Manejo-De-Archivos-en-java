/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lecturas;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author sergi
 */
public class ClaseFileReader {
    public static void main(String[] args) {
        System.out.println("Clase para leer");
        int caracter = 0;
        try {
            FileReader lectura = new FileReader("carpeta1\\ejemplo.txt");
            //Leyendo caracter por caracter
            caracter = lectura.read();
            while(caracter>=0){
                System.out.print((char)caracter);
                caracter = lectura.read();
            }
            lectura.close();
            
            lectura = new FileReader("carpeta1\\ejemplo.txt");
            
            //Leyendo todo el texto
            String todoTexto = lectura.readAllAsString();
            System.out.println("Leyendo todo: ");
            System.out.println(todoTexto);
            lectura.close();
            
            //Leyendo todas las lineas
            lectura = new FileReader("carpeta1\\ejemplo.txt");
            List<String> lineas = lectura.readAllLines();
            System.out.println("Total de lineas: "+lineas.size());
            for(String linea:lineas){
                System.out.println(linea);
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println("No se encontró el archivo");
        } catch (IOException ex) {
            System.out.println("Error al leer");
        }
        
    }
}
