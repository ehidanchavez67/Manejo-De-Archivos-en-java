package paquetefile;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author sergi
 */
public class ClaseFile {

    public static void main(String[] args) {
        String ruta = "C:\\Users\\sergi\\Desktop\\CarpetaPrueba\\OtraCarpeta\\";
        String archivo = "miArchivo.txt";
        File directorio = new File(ruta);

        directorio.mkdirs();
        
        File miArchivo = new File(ruta+archivo);
        
        try {
            if(miArchivo.exists()){
                System.out.println("El archivo ya existe");
            }
            else{
                miArchivo.createNewFile();
            System.out.println("Archivo creado");
            }
            
            
        } catch (IOException ex) {
            System.out.println("Ocurrió un fallo");
        }
        
        System.out.println("Directorio? "+directorio.isDirectory() );
        System.out.println("Directorio? "+miArchivo.isDirectory() );
        
        System.out.println("Archivo?: "+directorio.isFile());
        System.out.println("Archivo?: "+miArchivo.isFile());
       
        File[] listaArchivos = directorio.listFiles();
        
        System.out.println("Lista de archivos en la carpeta");
        for(File arch:listaArchivos){
            System.out.println(arch.getName());
        }
    }

}
