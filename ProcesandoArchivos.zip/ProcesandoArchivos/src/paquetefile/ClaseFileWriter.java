/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquetefile;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author sergi
 */
public class ClaseFileWriter {
    public static void main(String[] args) {
        System.out.println("Mi clase para escribir");
        try {
            FileWriter miArchivo = new FileWriter("C:\\Users\\sergi\\Desktop\\CarpetaPrueba\\OtraCarpeta\\miArchivo.txt",true);
            miArchivo.write("Hola, estoy escribiendo un archivo\n");
            miArchivo.write("\testa es otra escritura\n");
            miArchivo.close();
        } catch (IOException ex) {
            System.out.println("Ocurrió un error con el archivo");
        }
    }
}
