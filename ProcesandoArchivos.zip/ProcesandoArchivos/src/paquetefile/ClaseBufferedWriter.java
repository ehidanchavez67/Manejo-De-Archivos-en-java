/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquetefile;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author sergi
 */
public class ClaseBufferedWriter {
    public static void main(String[] args) {
        System.out.println("Clase Buffered Writer");
        
        File carpeta = new File("carpeta1");
        carpeta.mkdirs();
        
        try {
            FileWriter archivo = new FileWriter("carpeta1\\ejemplo.txt",true);
            BufferedWriter escritor = new BufferedWriter(archivo);
            
            escritor.write("Mi primera linea de texto\n");
            escritor.write("esta es otra linea");
            
            escritor.close();
            
        } catch (IOException ex) {
            System.out.println("Ocurrió un fallo");
        }
    }
}
